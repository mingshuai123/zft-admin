module.exports = {
  env: {
    jest: false
  }
}
